
public class Kadai1_2 {
	public static void main(String[] args){
		// 拡張for文でargsの中身をループする．
		for(String str : args){
			// ループごとに新しい中身がstrに格納されるのでstrでswitchする．
			switch(str){
			case "A":
				System.out.println("Ant");
				// 毎回breakを忘れないようにする．
				break;
			case "B":
				System.out.println("Boy");
				break;
			case "C":
				System.out.println("Cat");
				break;
			case "D":
				System.out.println("Dog");
				break;
			}
		}
	}
}
