
public class Kadai1_4 {
	public static void main(String[] args){
		int M = Integer.parseInt(args[0]);
		int N = Integer.parseInt(args[1]);
		int[][] array = new int[M][N];

		// MとNで二重ループを回す
		for(int i=0;i<M;i++){
			for(int j=0;j<N;j++){
				// 各要素には(m+1)*(n+1)が格納される．
				array[i][j] = (i+1)*(j+1);
				// 基本は半角スペース区切りで表示していく．
				System.out.print(array[i][j] + " ");
			}
			// 行が変わるタイミングでは改行を表示する．
			System.out.println("");
		}

	}
}
