
public class Kadai1_3 {
	public static void main(String[] args){
		int sum = 0;
		// 拡張for文でargsの中身をループする．
		for(String str:args){
			// int型にキャストしつつsumに加算する．
			sum += Integer.parseInt(str);
		}
		System.out.println(""+sum);
	}
}
