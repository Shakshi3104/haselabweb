
public class Kadai1_1 {
	public static void main(String[] args){
		// 配列の長さ (「I have a pen」の場合4が入る)
		int len = args.length;

		// i=0から，i<lenの間ループを回す．すなわちi=0,1,2,3となる．
		for(int i=0;i<len;i++){
			// args[]を0から順に表示していく．printなので改行はしない．
			System.out.print(args[i] + ",");
		}
	}
}
