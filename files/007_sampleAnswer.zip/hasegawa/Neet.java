
public class Neet extends Playboy{
	public Neet(String name, int hp, int mp){
		super(name, hp, mp, "�E�E�E");
	}

	@Override
	public int punch(){
		if(this.hp <= 3){
			return 500;
		}
		return super.punch();
	}
}
