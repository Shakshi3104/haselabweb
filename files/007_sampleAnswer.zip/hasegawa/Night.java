
public class Night extends Human{
	private double rate = 1.0;

	public Night(String name, int hp, int mp) {
		super(name, hp, mp);
	}

	public Night(String name, int lv){
		super(name, lv);
	}

	public void charge(){
		System.out.println("�C�������߂�");
		this.rate = 3;
	}

	public void diff(Night n){
		double diff = n.rate - this.rate;
		System.out.println("diff=" + diff);
	}

	@Override
	public int punch(){
		int res = (int)(super.punch()*1.5d*this.rate);
		this.rate = 1.0;
		return res;
	}

}
