
public class Playboy extends Human{
	private String shout = "";

	public Playboy(String name, int hp, int mp, String shout){
		super(name, hp, mp);
		this.shout = shout;
	}

	@Override
	public int punch(){
		System.out.println("��������ł���");
		System.out.println(this.shout);
		return 0;
	}

}
