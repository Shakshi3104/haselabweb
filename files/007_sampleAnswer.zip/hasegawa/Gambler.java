
public class Gambler extends Playboy{
	private int counter = 1;

	public Gambler(String name, int hp, int mp, String shout) {
		super(name, hp, mp, shout);
	}

	@Override
	public int punch(){
		//�K��3��Ɉ�x
		if(counter++ % 3 == 0){
			if(this.mp >= 10){
				this.mp -= 10;
				return 100;
			}
		}
		return super.punch();
	}
}
