
public class Human {
	protected String name = "";
	protected int hp = 0;
	protected int mp = 0;
	protected int lv = 0;

	public Human(String name, int hp, int mp){
		this.name = name;
		this.hp = hp;
		this.mp = mp;
		this.lv = 1;
	}

	public Human(String name, int lv){
		this.name = name;
		this.lv = lv;
		this.hp = lv*10;
		this.mp = lv*3;
	}

	public void status(){
		System.out.println(this.name + "Lv(" + this.lv + ")");
		System.out.println("HP("+this.hp+")");
		System.out.println("MP("+this.mp+")");
	}

	public int punch(){
		return 10;
	}

	public void item(){
		System.out.println("����������Ă��Ȃ�");
	}
}
