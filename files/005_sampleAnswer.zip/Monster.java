
public class Monster {
	int hp = 0;
	String name = "";
	int ap = 0;
	Weapon soubi;

	public Monster(int hp, String name, int ap){
		this.hp = hp;
		this.name = name;
		this.ap = ap;
	}

	public Monster(int hp, String name){
		this(hp, name, 0);
	}

	public String toString(){
		return this.hp + "," + this.name + "," + this.ap;
	}

	public int attack(){
		return this.ap;
	}

	public int attack2(){
		if(soubi == null){
			return this.attack();
		}
		return this.ap + soubi.ap;
	}

	public int attack3(){
		if(this.hp <= 5){
			if(soubi == null){
				return this.attack()*2;
			}
			return this.ap*2 + soubi.ap;
		}
		return this.attack2();
	}

	public int attack4(){
		if(this.hp < 10 && Math.random() < 0.5){
			this.hp += 10;
			System.out.println(this.name + "��HP��10�񕜂�"+this.hp+"�ƂȂ����D");
			return 0;
		}else{
			return this.attack3();
		}

	}

	public void damage(int val){
		this.hp -= val;
		if(this.hp > 0){
			System.out.println(this.name+"��"+val+"�̃_���[�W�I�c��HP"+this.hp);
		}else{
			this.hp = 0;
			System.out.println(this.name+"��"+val+"�̃_���[�W�I" + this.name+"��|�����I");
		}
	}

	public void setSoubi(Weapon soubi){
		this.soubi = soubi;
	}
}
