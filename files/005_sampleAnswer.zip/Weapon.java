
public class Weapon {
	String name = "";
	int ap = 0;

	public Weapon(String name, int ap){
		this.name = name;
		this.ap = ap;
	}
}
