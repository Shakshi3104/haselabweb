public class MyMethods{
	public static void translate(String str){
		// 送られてきたstrに応じてSwitch文で表示を変更する．
		switch(str){
		case "Ant":
			System.out.println("蟻");
			break;
		case "Boy":
			System.out.println("男の子");
			break;
		default:
			System.out.println("わかりません");
			break;
		}
	}
	
	public static double[] statistics(double[] values){
		// 戻り値を格納するための配列
		double[] res = new double[4];
		
		// res[2]は最大値，res[3]は最小値を格納するので
		// 初期値をvalues[0]として置くと楽である．
		res[2] = values[0];
		res[3] = values[0];
		
		for(double val : values){
			// res[0]には総和を
			res[0] += val;
			// res[2]よりもvalが大きければres[2]を更新する．
			if(val > res[2]) res[2] = val;
			// res[3]よりもvalが小さければres[3]を更新する．
			if(val < res[3]) res[3] = val;
		}
		// res[1]を更新してこなかったのは，総和が分かれば計算できるので．
		res[1] = res[0]/values.length;
		return res;
	}
	
	// int型の可変長引数でappendを定義する．
	public static void append(int... nums){
		int sum = 0;
		// ただ総和を計算するだけ
		for(int n : nums){
			sum += n;
		}
		System.out.println(""+sum);
	}
	
	// double型の可変長引数でappendを定義する．
	public static void append(double... nums){
		double sum = 0.0d;
		// ただ総和を計算するだけ
		for(double n : nums){
			sum += n;
		}
		System.out.println(""+sum);
	}
	
	// String型の可変長引数でappendを定義する．
	public static void append(String... nums){
		String sum = "";
		// 文字列をひたすら直結する．
		for(String n : nums){
			sum += n;
		}
		System.out.println(sum);
	}
}
